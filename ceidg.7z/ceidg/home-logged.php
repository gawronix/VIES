<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Lista Firm - CEDIG & VIES</title>
    <link rel="stylesheet" href="login.css">
    <style>
        table {
            border-collapse: collapse;
        }
        table, td, th {
            border: 1px solid black;
        }
    </style>
</head>

<body>
<div class="container">
    <div id="login-box">
        <table class="table table-striped" class="hover">
            <h1 color="white" align="center" >Dane Wybranej Firmy</h1>
        <tr>
            <th>#</th>
            <th>Nazwa firmy</th>
            <th>NIP</th>
            <th>REGON</th>
            <th>Numer Telefonu</th>
            <th>Mail</th>
            <th>Strona www</th>
            <th>Data Otwarcia</th>
        </tr>
            <tr>
                <th>1</th>
                <th>danreeasd</th>
                <th>danreeasd</th>
                <th>danreeasd</th>
                <th>N42142124124</th>
                <th>Maasffas@il</th>
                <th>www/sexiflex.i </th>
                <th>23123./2323</th>

            </tr>
    </div><!-- /.controls -->
    </table>
</div><!-- /#login-box -->
</div><!-- /.container -->
<div id="particles-js"></div>
<script
        src="https://code.jquery.com/jquery-3.2.1.js"
        integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
        crossorigin="gawron"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
<script src="login.js"></script>
</body>
</html>

