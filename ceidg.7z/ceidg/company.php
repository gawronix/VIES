<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Firma - CEDIG & VIES</title>
    <link rel="stylesheet" href="login.css">
</head>

<body>
<div class="container">
    <div id="login-box">
        <div class="container">
            <div class="panel panel-default">
                <div class="panel-heading text-center">
                    <h1><?php echo $company["Firma"];?></h1>
                </div>
                <div class="panel-body">
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading text-center">
                                <h3>Dane Podstawowe:</h3>
                            </div>
                            <div class="panel-body" >
                                <p>Imie: <b><?php echo $company['Imie'];?></b></p>
                                <p>Nazwisko: <b><?php echo $company['Nazwisko'];?></b></p>
                                <p>NIP: <b><?php echo $company['NIP'];?></b></p>
                                <p>REGON: <b><?php echo $company['REGON'];?></b></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading text-center">
                                <p><h3>Dane kontaktowe:</h3></p>
                            </div>
                            <div class="panel-body">
                                <p>Adres e-mail: <b><?php echo $company['AdresPocztyElektronicznej'];?></b></p>
                                <p>Strona internetowa: <b><?php echo $company['AdresStronyInternetowej'];?></b></p>
                                <p>Telefon: <b style="color: red"><?php echo $company['Telefon'];?></b></p>
                                <p>Adres e-mail: <b style="color: red"><?php echo $company['AdresPocztyElektronicznej'];?></b></p>
                                <p>Faks: <b><?php echo $company['Faks'];?></b></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading text-center">
                                <p><h3>Dane Adresowe:</h3></p>
                            </div>
                            <div class="panel-body">
                                <p>Powiat: <b><?php echo $company['Powiat'];?></b></p>
                                <p>Województwo: <b><?php echo $company['Wojewodztwo'];?></b></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.controls -->
</div><!-- /#login-box -->
</div><!-- /.container -->
<div id="particles-js"></div>
<script
        src="https://code.jquery.com/jquery-3.2.1.js"
        integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
        crossorigin="gawron"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
<script src="login.js"></script>
</body>
</html>

